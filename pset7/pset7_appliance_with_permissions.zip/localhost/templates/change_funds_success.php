<div class="alert alert-success">
    You have succesfully deposited additional funds.
</div>
