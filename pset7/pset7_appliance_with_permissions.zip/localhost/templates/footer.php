            </div>

            <div id="bottom">
                All stock data is delayed by 15 minutes. Copyright &#169; Edward Poot
            </div>

        </div>

    </body>

</html>
