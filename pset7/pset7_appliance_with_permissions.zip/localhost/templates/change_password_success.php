<div class="alert alert-success">
    Your password has been succesfully changed. From now on, login with this new password!
</div>
