<div id="funds_placeholder">
    <p id="spinner">
        <img src="/img/spinner.gif" alt="Loading.."/>
    </p>
</div>

<form id="change_funds_form">
      <div class="row">
        <div class="col-md-6 col-md-offset-3">          
            <div class="form-group">
                <input class="form-control" autofocus name="funds_amount" placeholder="Enter additional funds" type="text"/>
            </div>       
            <div class="form-group">
                <input type="submit" name="submit" class="btn btn-warning btn-lg btn-block" value="Deposit additional funds"/>
            </div>
        </div>      
    </div>
</form>
